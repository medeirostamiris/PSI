from flask import Flask, render_template, request, make_response, redirect, url_for, session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'tamiris123455'
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cadastro', methods= ['GET', 'POST'])
def cadastro():
    if request.method == 'GET':
        return render_template('cadastro.html')
    else:
        # 'nome' é o atributo 'name' do input
        nome = request.form['nome']
        genero = request.form['genero']
        session['user'] = nome
        response = make_response(redirect(url_for("preferencia")))
        response.set_cookie(nome, genero, max_age=7*24*3600)
        #return "Em construção " + genero
        return response

@app.route('/preferencia')
def preferencia():
    
    if 'user' in session:
        user = session.get('user')
        if user in request.cookies:
            genero = request.cookies.get(user)
            return user + " - " + genero
    return '<h1> Deu ruim <h1>'
@app.route('/recomendar')
def recomendar():
    Filmes = {
        'acao' : ['estudar', 'prova'],
        'comedia' : ['As branquelas', 'liv'],
        'drama' : ['quero ir embora' , 'isa'],
        'terror' : ['fran', 'tata']

    }
    if 'genero' not in request.args:
        return 'genero não informado'
    genero = request.args.get('genero')
    if genero in Filmes.keys():
        lista = Filmes[genero]
    return render_template('filmes.html', Filmes=lista)
