from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'LIFT'

usuarios = {}

@app.route('/')
def index():
    usuario = session.get('usuario')
    return render_template('index.html', usuario=usuario)

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['usuario']
        senha = request.form['senha']
        if nome in usuarios:
            return 'Usuário já existe. Escolha outro nome.'
        senha_hash = generate_password_hash(senha)
        usuarios[nome] = senha_hash
        return redirect(url_for('login'))
    return render_template('cadastro.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nome = request.form['usuario']
        senha = request.form['senha']
        senha_hash = usuarios.get(nome)

        if senha_hash and check_password_hash(senha_hash, senha):
            session['usuario'] = nome
            return redirect(url_for('index'))
        else:
            return 'Usuário ou senha inválidos.'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('usuario', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

# Lista fixa de produtos (nome e preço)
lista_produtos = [
    {'id': 1, 'nome': 'Blusa', 'preco': 79.90},
    {'id': 2, 'nome': 'Calça', 'preco': 149.90},
    {'id': 3, 'nome': 'Tênis', 'preco': 199.90},
    {'id': 4, 'nome': 'Lenço', 'preco': 29.90}
]

@app.route('/produtos', methods=['GET', 'POST'])
def produtos():
    if 'usuario' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        produto_id = int(request.form['produto_id'])

        produto = next((p for p in lista_produtos if p['id'] == produto_id), None)
        if produto:
            usuario = session['usuario']
            if 'carrinhos' not in session:
                session['carrinhos'] = {}
            if usuario not in session['carrinhos']:
                session['carrinhos'][usuario] = []

            session['carrinhos'][usuario].append(produto)
            session.modified = True

    return render_template('produtos.html', produtos=lista_produtos)



@app.route('/carrinho')
def carrinho():
    if 'usuario' not in session:
        return redirect(url_for('login'))

    usuario = session['usuario']
    carrinhos = session.get('carrinhos', {})
    carrinho = carrinhos.get(usuario, [])
    total = sum(item['preco'] for item in carrinho)

    return render_template('carrinho.html', carrinho=carrinho, total=total)
